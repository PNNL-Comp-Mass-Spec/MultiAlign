This parameter pack file works with 

5.0.1
	12-19-2012
5.0.2 
	1-9-2013